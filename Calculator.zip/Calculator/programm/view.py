def view_data(data, result):
    print(f'\n{data} = {result}\n')
